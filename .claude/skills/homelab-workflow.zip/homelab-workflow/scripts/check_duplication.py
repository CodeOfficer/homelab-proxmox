#!/usr/bin/env python3
"""
Check for duplicate information between CLAUDE.md and docs/ files.
This enforces the "single source of truth" pattern.
"""

import os
import sys
import re
from pathlib import Path
from difflib import SequenceMatcher

# Words that indicate potential duplication (case-insensitive)
HARDWARE_KEYWORDS = [
    "minisforum", "ms-01", "rteon", "rtx 4000", "ugreen", "unas pro",
    "synology", "ds713", "jetkvm", "96gb", "2tb nvme"
]

NETWORK_KEYWORDS = [
    "10.20.11", "10.20.10", "vlan 11", "vlan 10", "udm pro",
    "usw-enterprise", "vm-servers", "core-infrastructure"
]

SOFTWARE_KEYWORDS = [
    "proxmox ve", "k3s", "ubuntu 24.04", "metallb", "fluxcd",
    "traefik", "cert-manager", "ollama"
]

def similarity_ratio(str1, str2):
    """Calculate similarity ratio between two strings."""
    return SequenceMatcher(None, str1.lower(), str2.lower()).ratio()

def find_duplicates(project_root):
    """Find potential duplications between CLAUDE.md and docs/ files."""
    claude_md = project_root / "CLAUDE.md"
    docs_dir = project_root / "docs"

    if not claude_md.exists():
        print("❌ CLAUDE.md not found")
        return 1

    if not docs_dir.exists():
        print("❌ docs/ directory not found")
        return 1

    # Read CLAUDE.md
    with open(claude_md, 'r') as f:
        claude_content = f.read()
    claude_lower = claude_content.lower()

    issues_found = []

    # Check for hardware keywords in CLAUDE.md
    for keyword in HARDWARE_KEYWORDS:
        if keyword in claude_lower:
            # Find line numbers
            lines = claude_content.split('\n')
            line_nums = [i+1 for i, line in enumerate(lines) if keyword in line.lower()]
            if line_nums:
                issues_found.append({
                    'type': 'HARDWARE',
                    'keyword': keyword,
                    'file': 'CLAUDE.md',
                    'lines': line_nums
                })

    # Check for network keywords in CLAUDE.md
    for keyword in NETWORK_KEYWORDS:
        if keyword in claude_lower:
            lines = claude_content.split('\n')
            line_nums = [i+1 for i, line in enumerate(lines) if keyword in line.lower()]
            if line_nums:
                issues_found.append({
                    'type': 'NETWORK',
                    'keyword': keyword,
                    'file': 'CLAUDE.md',
                    'lines': line_nums
                })

    # Check for software version keywords in CLAUDE.md
    for keyword in SOFTWARE_KEYWORDS:
        if keyword in claude_lower:
            lines = claude_content.split('\n')
            line_nums = [i+1 for i, line in enumerate(lines) if keyword in line.lower()]
            if line_nums:
                issues_found.append({
                    'type': 'SOFTWARE',
                    'keyword': keyword,
                    'file': 'CLAUDE.md',
                    'lines': line_nums
                })

    return issues_found

def main():
    project_root = Path(__file__).parent.parent.parent.parent

    print("🔍 Checking for duplicate information...")
    print("━" * 50)

    issues = find_duplicates(project_root)

    if isinstance(issues, int):
        return issues

    if not issues:
        print("✅ No duplication detected")
        print("   CLAUDE.md contains only plan/architecture")
        print("   docs/ files contain specifications")
        return 0

    print(f"⚠️  Found {len(issues)} potential duplications:\n")

    # Group by type
    hardware_issues = [i for i in issues if i['type'] == 'HARDWARE']
    network_issues = [i for i in issues if i['type'] == 'NETWORK']
    software_issues = [i for i in issues if i['type'] == 'SOFTWARE']

    if hardware_issues:
        print("📦 HARDWARE specs found in CLAUDE.md:")
        print("   Should be ONLY in docs/HARDWARE.md")
        for issue in hardware_issues:
            print(f"   - '{issue['keyword']}' at lines {issue['lines']}")
        print()

    if network_issues:
        print("🌐 NETWORK config found in CLAUDE.md:")
        print("   Should be ONLY in docs/NETWORK.md")
        for issue in network_issues:
            print(f"   - '{issue['keyword']}' at lines {issue['lines']}")
        print()

    if software_issues:
        print("💿 SOFTWARE versions found in CLAUDE.md:")
        print("   Should be ONLY in docs/SOFTWARE.md")
        for issue in software_issues:
            print(f"   - '{issue['keyword']}' at lines {issue['lines']}")
        print()

    print("━" * 50)
    print("💡 Recommendations:")
    print("   - Remove specifications from CLAUDE.md")
    print("   - Keep only architecture decisions/rationale")
    print("   - Reference docs/ files when needed")

    return 1

if __name__ == "__main__":
    sys.exit(main())
